echo > a_noinh_pattern.txt
echo > b_noinh_pattern.txt
echo > a_random_pattern.txt
echo > b_random_pattern.txt
echo > a_trained_pattern.txt
echo > b_trained_pattern.txt
echo > a_source_pattern.txt
echo > b_source_pattern.txt
